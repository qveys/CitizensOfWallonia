export interface Activity {
  id: string
  title: string
  description: string
  type: string
  date: string
  status: string
  url: string
}

